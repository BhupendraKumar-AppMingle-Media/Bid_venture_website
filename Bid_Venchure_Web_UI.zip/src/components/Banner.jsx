import React from "react";

const Banner = () => {
  return (
    <div className="flex flex-col items-center justify-center mt-20">
      {/* Top Section */}
      <div
        className="relative w-full h-[50vh] bg-cover bg-center text-center flex items-center justify-center"
        style={{
          backgroundImage: `url('https://source.unsplash.com/random/1600x900/?nature,water')`, // Replace with any suitable online image
        }}
      >
        {/* Overlay */}
        <div className="absolute inset-0  bg-[#483058]"></div>

        {/* Content */}
        <div className="relative z-10 text-white">
          <h1 className="text-4xl md:text-5xl font-bold mb-2">BID VENCHURE</h1>
          <div className="mt-4 border-t-2 border-white w-12 mx-auto"></div>
          <p className="text-lg mt-2 font-light">Your Event, Their Best Offer!</p>
        </div>
      </div>

      {/* Bottom Section */}
      <div className="bg-[#d2273f] w-full px-6 py-20 text-center">
        <div className="flex flex-col items-center space-y-4">
          {/* Paragraph */}
          <p className="max-w-xl mx-auto text-white">
            Effortlessly plan your event by letting restaurants bid for your business. Save time, money, and stress.
          </p>

          {/* Buttons in Row */}
          <div className="flex space-x-4 mt-4">
            <button className="bg-[#483058] border-2 text-white px-6 py-2 rounded-md hover:bg-transparent hover:text-white transition duration-300">
              Post Your Event Now
            </button>
            <button className="bg-[#483058] border-2 text-white px-6 py-2 rounded-md hover:bg-transparent hover:text-white transition duration-300">
              Join as a Restaurant
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Banner;
