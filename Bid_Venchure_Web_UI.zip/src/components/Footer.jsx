import React from "react";
import { FaFacebookF, FaTwitter, FaInstagram, FaLinkedinIn } from "react-icons/fa"; // Social Icons
import { FiPhone, FiMail } from "react-icons/fi"; // Contact Icons
import { HiOutlineLocationMarker } from "react-icons/hi"; // Location Icon
import { FaGooglePlay, FaApple } from "react-icons/fa"; // App Download Icons

const Footer = () => {
  return (
    <footer className="bg-[#483058] text-white py-10 px-6">
      <div className="container mx-auto grid grid-cols-1 md:grid-cols-4 gap-8">
        {/* Column 1 - Logo and Description */}
        <div>
          <h2 className="text-2xl font-bold text-red-500">Bid <span className="text-white">Venchure</span></h2>
          <p className="mt-4 text-sm">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos, fugit non. Incidunt dolorum adipisci, 
            tempore asperiores nemo odio facere officiis enim animi placeat eaque nesciunt alias beatae id, at dicta.
          </p>
          {/* Social Icons */}
          <div className="flex mt-4 space-x-4">
            <FaFacebookF className="w-8 h-8 text-white hover:text-blue-500 cursor-pointer" />
            <FaTwitter className="w-8 h-8 text-white hover:text-blue-400 cursor-pointer" />
            <FaInstagram className="w-8 h-8 text-white hover:text-pink-500 cursor-pointer" />
            <FaLinkedinIn className="w-8 h-8 text-white hover:text-blue-700 cursor-pointer" />
          </div>
        </div>

        {/* Column 2 - Contact Info */}
        <div>
          <ul className="space-y-4">
            <li className="flex items-center space-x-2">
              <FiPhone className="text-xl" />
              <span className="font-bold">+91 1800123444</span>
              {/* <p className="text-sm">Support Number</p> */}
            </li>
            <li className="flex items-center space-x-2">
              <FiMail className="text-xl" />
              <span className="font-bold">help@lorem.com</span>
              {/* <p className="text-sm">Support Email</p> */}
            </li>
            <li className="flex items-center space-x-2">
              <HiOutlineLocationMarker className="text-xl" />
              <span className="font-bold">Sub Nerul, Mumbai, India, 123456</span>
              {/* <p className="text-sm">Address</p> */}
            </li>
          </ul>
        </div>

        {/* Column 3 - Pages */}
        <div>
          <h3 className="font-bold text-lg  mb-4 ">Pages</h3>
          <ul className="space-y-2">
            <li>Home</li>
            <li>Works</li>
            <li>Service</li>
          
          </ul>
        </div>
        {/* cloumn - 4 */}
        <div>
          <h3 className="font-bold text-lg mb-4">More Pages</h3>
          <ul className="space-y-2">
          
            <li>Event</li>
            <li>About Us</li>
            <li>Contact Us</li>
          </ul>
        </div>

        {/* Column 5 - Download the App */}
        <div>
          <h3 className="font-bold text-lg mb-4">Download the app</h3>
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <FaGooglePlay className="w-8 h-8 text-white" />
              <span>Get it on Google Play</span>
            </div>
            {/* <div className="flex items-center space-x-2">
              <FaApple className="w-8 h-8 text-white" />
              <span>Download on the App Store</span>
            </div> */}
          </div>
        </div>
      </div>

      {/* Footer Bottom */}
      <div className="mt-8 border-t border-white/10 pt-4 text-center text-sm">
        © Copyright 2024, All Rights Reserved by YOUR WEBSITES. PVT. LTD
      </div>
    </footer>
  );
};

export default Footer;
