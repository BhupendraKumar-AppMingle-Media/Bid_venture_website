import React from "react";
import Banner from "./Banner.jsx";
import Footer from "./Footer.jsx";
import Header from "./Header.jsx";
import WhyChooseUs from "./WhyChooseUs.jsx";
import WorksSection from "./WorksSection.jsx";


const Main = () => {
  return (
    <>
      <Header />
      <Banner />
      <WhyChooseUs />
      <WorksSection />
      {/* <Gallery /> */}
      {/* <OurTeamSection /> */}
      {/* <Testimonial/> */}
      {/* <GetInTouch /> */}
      <Footer />

      
    </>
  );
};

export default Main;
