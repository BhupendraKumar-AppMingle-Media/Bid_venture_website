import logo1 from "../images/logo.png";
import { Link } from "react-router-dom";

const Header = () => {
  return (
    <div id="header">
      {/* Header Container */}
      <header className="fixed top-0 w-full z-50 flex justify-between items-center px-8 py-4 bg-white shadow-md">
        {/* Logo Section */}
        <div className="header-logo">
          <img src={logo1} alt="Logo" className="h-16 w-auto" />
        </div>

        {/* Navigation Links */}
        <nav className="flex flex-col lg:flex-row items-center space-y-4 lg:space-y-0 lg:space-x-8">
          
          <Link
            to='/'
            className="block relative hover:after:w-full after:w-0 after:h-[2px] after:bg-[#5a39fe] after:block after:transition-all after:duration-300 after:origin-left"
          >
           Home
          </Link>
          <Link
            to='/works'
            className="block relative hover:after:w-full after:w-0 after:h-[2px] after:bg-[#5a39fe] after:block after:transition-all after:duration-300 after:origin-left"
          >
           Works
          </Link>
          <Link
           to ='/services'
            className="block relative hover:after:w-full after:w-0 after:h-[2px] after:bg-[#5a39fe] after:block after:transition-all after:duration-300 after:origin-left"
          >
           Service
          </Link>
          <Link
            to='/event'
            className="block relative hover:after:w-full after:w-0 after:h-[2px] after:bg-[#5a39fe] after:block after:transition-all after:duration-300 after:origin-left"
          >
            Event
          </Link>
          <Link
            to='/aboutus'
            className="block relative hover:after:w-full after:w-0 after:h-[2px] after:bg-[#5a39fe] after:block after:transition-all after:duration-300 after:origin-left"
          >
           About Us 
          </Link>
          <Link
            to ='/contactus'
            className="block relative hover:after:w-full after:w-0 after:h-[2px] after:bg-[#5a39fe] after:block after:transition-all after:duration-300 after:origin-left"
          >
            Contact Us 
          </Link>
        </nav>
      </header>
    </div>
  );
};

export default Header;
