import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';

const Services = () => {
  return (
    <>
    <Header />
    <div className="bg-gray-50 py-16 mt-20">
      

      <div className="container mx-auto px-6 lg:px-16 text-center">
        {/* Heading */}
        <h1 className="text-4xl font-bold text-gray-800 mb-6">
          Turn Opportunities into Bookings
        </h1>

        {/* Subtext */}
        <p className="text-lg text-gray-600 mb-12">
          Fill empty tables, boost your visibility, and grow your revenue. Our platform helps you connect with event organizers looking for your services.
        </p>

        {/* Key Benefits Section */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          <div className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-300">
            <div className="text-purple-600 text-3xl mb-4">
              <i className="fas fa-bullseye"></i>
            </div>
            <h3 className="text-xl font-semibold text-gray-800 mb-4">Targeted Opportunities</h3>
            <p className="text-gray-600">
              Receive event leads tailored to your offerings. Our platform matches you with the right clients.
            </p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-300">
            <div className="text-purple-600 text-3xl mb-4">
              <i className="fas fa-handshake"></i>
            </div>
            <h3 className="text-xl font-semibold text-gray-800 mb-4">Fair Competition</h3>
            <p className="text-gray-600">
              Compete based on your unique value, not just price. Showcase your strengths to attract more clients.
            </p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-300">
            <div className="text-purple-600 text-3xl mb-4">
              <i className="fas fa-chart-line"></i>
            </div>
            <h3 className="text-xl font-semibold text-gray-800 mb-4">Revenue Growth</h3>
            <p className="text-gray-600">
              Fill bookings during slow periods and reach new audiences. Grow your revenue by tapping into new opportunities.
            </p>
          </div>
        </div>

        {/* Success Stories Section */}
        <div className="bg-white p-8 rounded-lg shadow-lg mb-12">
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">Success Stories</h2>
          <p className="text-lg text-gray-600 italic mb-4">
            "This platform has transformed our business! We've doubled our event bookings in just three months."
          </p>
          <p className="text-gray-800 font-semibold">— Chef Anthony, Italian Bistro</p>
        </div>

        {/* CTA Section */}
        <div className="bg-purple-600 text-white p-8 rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-300">
          <h2 className="text-2xl font-semibold mb-4">Sign up today and start winning more business!</h2>
          <button className="bg-white text-purple-600 font-semibold py-2 px-6 rounded-lg hover:bg-gray-100 transition-all duration-300">
            Get Started
          </button>
        </div>
      </div>

      
    </div>
    <Footer />

    </>
  );
};

export default Services;
